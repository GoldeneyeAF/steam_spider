import scrapy
from spider_steam.items import SpiderSteamItem

import re

queries = ['among', 'call', 'war']


class SteamproductspiderSpider(scrapy.Spider):
    name = 'SteamProductSpider'

    def start_requests(self):
        pages = ['1', '2']
        for query in queries:
            for page in pages:
                url = 'https://store.steampowered.com/search/?term=' + query + '&page=' + page
                yield scrapy.Request(url, callback=self.parse_keyword_response)

    def parse_keyword_response(self, response):
        products = set()

        for i in response.css('a::attr(href)').getall():
            if re.search(r'app', i):
                products.add(i)

        for product in products:
            yield scrapy.Request(product, callback=self.parse)

    def parse(self, response):

        items = SpiderSteamItem()
        game_name = response.xpath('//div[@class = "blockbg"]/a/span[@itemprop = "name"]/text()').extract()
        game_category = response.xpath('//div[@class = "blockbg"]/a/text()').extract()
        game_release_date = response.xpath('//div[@class="release_date"]/div[@class="date"]/text()').extract()
        game_review_score = response.xpath('//div [@class="summary column"]/span[@class="nonresponsive_hidden responsive_reviewdesc"]/text()').extract()
        game_reviews_cnt = response.xpath('//div [@class="summary column"]/span[@class="responsive_hidden"]/text()').extract()
        game_developer = response.xpath('//div[@id="developers_list"]/a/text()').extract()
        game_tags = response.xpath('//a[@class="app_tag"]/text()').extract()
        game_price = response.xpath('//div[@class="game_purchase_action"]/div[@class="game_purchase_action_bg"]/div[@class="game_purchase_price price"]/text()').extract()
        game_platforms = response.xpath('//div[@class="sysreq_tabs"]/div/text()').extract()

        items["game_name"] = ''.join(game_name).strip()
        items["game_category"] = '/'.join(game_category).strip().replace("All Games", "")
        items["game_release_date"] = ''.join(game_release_date).strip()
        items["game_review_score"] = ''.join(game_review_score).strip().replace("\t", "").replace("\n", "").replace("\r", "")
        items["game_reviews_cnt"] = ''.join(game_reviews_cnt).strip().replace("\t", "").replace("\n", " ").replace("\r", "")
        items["game_developer"] = ''.join(game_developer).strip()
        items["game_tags"] = ''.join(game_tags).strip().replace("\t", "").replace("\n", ", ").replace("\r", "")
        items["game_price"] = ''.join(game_price).strip().replace("\t", "").replace("\n", ", ").replace("\r", "")
        items["game_platforms"] = ''.join(game_platforms).strip().replace("\t", "").replace("\n", ", ").replace("\r", "")

        yield items
